- Operating System: 
- Python Version: 
- Sonoff model: 
- Sonoff firmware version: 
- I have read the README, and understand that SonOTA does not work with the latest Sonoff firmware: 

Please also drag and drop the generated `debug_########.log` file onto the issue so it is attached.

